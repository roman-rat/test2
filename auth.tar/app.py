from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from auth import auth_bp
from courses import courses_bp
import os

# Инициализация приложения Flask
app = Flask(__name__)

# Настройки приложения
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://flask_user:password@localhost/flask_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Инициализация базы данных
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Регистрация Blueprint'ов
app.register_blueprint(auth_bp, url_prefix='/auth')
app.register_blueprint(courses_bp, url_prefix='/courses')

# Главная страница
@app.route('/')
def index():
    return render_template('index.html')

# Страница профиля пользователя
@app.route('/profile')
def profile():
    return render_template('profile.html')

# Запуск приложения
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=443, ssl_context=("/etc/ssl/certs/flask_app.crt", "/etc/ssl/private/flask_app.key"))