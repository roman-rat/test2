from flask import render_template, redirect, url_for, flash, request, session
from werkzeug.security import generate_password_hash, check_password_hash
from . import auth_bp

# Пример "базы данных" пользователей (замените на реальную базу данных)
users = {
    "test@example.com": {
        "name": "Test User",
        "password": generate_password_hash("password123")  # Захешированный пароль
    }
}

# Маршрут для входа
@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        # Проверка пользователя
        user = users.get(email)
        if user and check_password_hash(user['password'], password):
            session['user'] = {"email": email, "name": user['name']}
            flash('Вы успешно вошли!', 'success')
            return redirect(url_for('courses.category_page', category_id='virtualization_automation'))
        else:
            flash('Неверный email или пароль.', 'danger')

    return render_template('login.html')

# Маршрут для регистрации
@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')

        if email in users:
            flash('Этот email уже зарегистрирован.', 'danger')
        elif password != confirm_password:
            flash('Пароли не совпадают.', 'danger')
        else:
            # Добавление нового пользователя
            users[email] = {
                "name": name,
                "password": generate_password_hash(password)
            }
            flash('Регистрация успешна! Теперь вы можете войти.', 'success')
            return redirect(url_for('auth.login'))

    return render_template('register.html')

# Маршрут для выхода
@auth_bp.route('/logout')
def logout():
    session.pop('user', None)
    flash('Вы вышли из системы.', 'info')
    return redirect(url_for('auth.login'))
