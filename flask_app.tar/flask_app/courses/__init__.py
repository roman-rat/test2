from flask import Blueprint

# Создаем Blueprint для модуля курсов
courses_bp = Blueprint('courses', __name__, template_folder='templates/topics', static_folder='static')

from . import routes
