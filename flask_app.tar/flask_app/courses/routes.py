from flask import render_template, abort
from . import courses_bp

# Данные категорий
categories = {
    "virtualization_automation": "Виртуализация и автоматизация",
    "file_systems_management": "Файловые системы и управление данными",
    "packages_system_initialization": "Управление пакетами и загрузка системы",
    "linux_programming": "Программирование и администрирование в Linux",
    "security_isolation": "Безопасность и изоляция",
    "containerization_management": "Контейнеризация и управление",
    "monitoring_logging": "Мониторинг и логирование",
    "networks_protocols": "Сети и протоколы",
    "web_dev_databases": "Веб-разработка и базы данных",
}

# Данные курсов
courses = {
    "vagrant": {"category": "virtualization_automation", "title": "Vagrant"},
    "ansible_1": {"category": "virtualization_automation", "title": "Ansible-1"},
    "ansible_2": {"category": "virtualization_automation", "title": "Ansible-2"},
    "disk_subsystem": {"category": "file_systems_management", "title": "Дисковая подсистема"},
    "file_systems_lvm": {"category": "file_systems_management", "title": "Файловые системы и LVM - 1"},
    "zfs": {"category": "file_systems_management", "title": "ZFS"},
    "nfs_fuse": {"category": "file_systems_management", "title": "NFS, FUSE"},
    "backup": {"category": "file_systems_management", "title": "Резервное копирование"},
    "mysql_backup_replication": {"category": "file_systems_management", "title": "MySQL: Backup + Репликация"},
    "postgresql_backup_replication": {"category": "file_systems_management", "title": "PostgreSQL: Backup + Репликация"},
    "packages_distribution": {"category": "packages_system_initialization", "title": "Управление пакетами"},
    "system_boot": {"category": "packages_system_initialization", "title": "Загрузка системы"},
    "systemd_initialization": {"category": "packages_system_initialization", "title": "Инициализация системы"},
    "bash": {"category": "linux_programming", "title": "Bash"},
    "text_processing": {"category": "linux_programming", "title": "grep, sed, awk и другие"},
    "process_management": {"category": "linux_programming", "title": "Управление процессами"},
    "memory_management": {"category": "linux_programming", "title": "Работа с памятью"},
    "namespaces_cgroups": {"category": "security_isolation", "title": "Изоляция Linux (namespaces и cgroups)"},
    "selinux": {"category": "security_isolation", "title": "SELinux"},
    "ldap": {"category": "security_isolation", "title": "LDAP"},
    "user_management": {"category": "security_isolation", "title": "Пользователи и группы"},
    "docker_basics": {"category": "containerization_management", "title": "Docker - основы"},
    "docker_volumes_networks": {"category": "containerization_management", "title": "Docker: Volumes и Networks"},
    "performance_monitoring": {"category": "monitoring_logging", "title": "Мониторинг производительности"},
    "prometheus": {"category": "monitoring_logging", "title": "Prometheus"},
    "zabbix": {"category": "monitoring_logging", "title": "Zabbix"},
    "logs_basics": {"category": "monitoring_logging", "title": "Основы сбора логов"},
    "elk": {"category": "monitoring_logging", "title": "Сбор и анализ логов ELK"},
    "network_architecture": {"category": "networks_protocols", "title": "Архитектура сетей"},
    "dhcp_pxe": {"category": "networks_protocols", "title": "DHCP, PXE"},
    "iptables": {"category": "networks_protocols", "title": "iptables"},
    "firewalld": {"category": "networks_protocols", "title": "firewalld"},
    "nftables": {"category": "networks_protocols", "title": "nftables"},
    "ospf_routing": {"category": "networks_protocols", "title": "OSPF"},
    "bgp": {"category": "networks_protocols", "title": "BGP"},
    "bridges_tunnels_vpn": {"category": "networks_protocols", "title": "Мосты, туннели, VPN"},
    "dns": {"category": "networks_protocols", "title": "DNS"},
    "vlan_lacp": {"category": "networks_protocols", "title": "VLAN, LACP"},
    "ipv6": {"category": "networks_protocols", "title": "IPv6"},
    "web_protocols": {"category": "networks_protocols", "title": "Web-протоколы"},
    "nginx": {"category": "web_dev_databases", "title": "Nginx"},
    "dynamic_web": {"category": "web_dev_databases", "title": "Динамический веб"},
    "mysql": {"category": "web_dev_databases", "title": "MySQL"},
    "postgresql": {"category": "web_dev_databases", "title": "PostgreSQL"},
}

# Маршрут для категорий
@courses_bp.route('/categories/<category_id>')
def category_page(category_id):
    if category_id not in categories:
        abort(404)
    category_name = categories[category_id]
    category_courses = {k: v for k, v in courses.items() if v["category"] == category_id}
    return render_template(f"categories/{category_id}.html", category_name=category_name, courses=category_courses)

# Маршрут для подтем
@courses_bp.route('/courses/<course_id>')
def course_page(course_id):
    if course_id not in courses:
        abort(404)
    course_data = courses[course_id]
    return render_template(f"topics/{course_id}.html", course=course_data)
