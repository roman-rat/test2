-- Тесты для Vagrant
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(1, 'Что такое Vagrant?', '["Инструмент для создания виртуальных окружений", "Язык программирования", "Система контроля версий"]', 0),
(1, 'Какой файл используется для настройки Vagrant?', '["config.json", "Vagrantfile", "vm_config.yml"]', 1),
(1, 'Какая команда используется для запуска виртуальной машины?', '["vagrant start", "vagrant up", "vagrant run"]', 1),
(1, 'Какая команда используется для подключения к виртуальной машине?', '["vagrant connect", "vagrant ssh", "vagrant access"]', 1),
(1, 'Что происходит при выполнении команды `vagrant destroy`?', '["Удаляется виртуальная машина", "Машина перезагружается", "Машина останавливается"]', 0);

-- Тесты для Ansible-1
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(2, 'Какой формат используется для написания playbook?', '["YAML", "JSON", "XML"]', 0),
(2, 'Как называется файл для описания задач в Ansible?', '["Playbook", "Inventory", "Config file"]', 0),
(2, 'Какую команду использовать для проверки доступности серверов?', '["ansible-playbook test.yml", "ansible all -m ping", "ansible-ping all"]', 1),
(2, 'Как Ansible подключается к серверам?', '["Через SSH", "Через HTTP", "Через FTP"]', 0),
(2, 'Какой модуль используется для установки пакетов?', '["apt", "package", "service"]', 0);

-- Тесты для Ansible-2
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(3, 'Что такое роль в Ansible?', '["Структура для организации playbook", "Файл конфигурации", "Модуль для управления пакетами"]', 0),
(3, 'Какой язык используется для шаблонов в Ansible?', '["Jinja2", "YAML", "XML"]', 0),
(3, 'Как указать условие в задаче Ansible?', '["Использовать `when`", "Использовать `if`", "Использовать `condition`"]', 0),
(3, 'Какой модуль используется для управления системными сервисами?', '["file", "service", "user"]', 1),
(3, 'Что делает команда `ansible-playbook site.yml`?', '["Выполняет указанный playbook", "Проверяет доступность серверов", "Устанавливает Ansible"]', 0);

-- Тесты для Дисковая подсистема
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(4, 'Что такое файловая система?', '["Формат данных для хранения и доступа к файлам", "Интерфейс для работы с сетью", "Программа для управления процессами"]', 0),
(4, 'Какая команда показывает информацию о дисках и разделах?', '["lsblk", "df", "top"]', 0),
(4, 'Какой инструмент используется для управления разделами с поддержкой GPT?', '["parted", "fdisk", "mount"]', 0),
(4, 'Какая файловая система поддерживает снапшоты?', '["Btrfs", "ext4", "XFS"]', 0),
(4, 'Какая файловая система наиболее подходит для серверов?', '["ext4", "XFS", "Btrfs"]', 1);
-- Тесты для Файловые системы и LVM - 1
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(5, 'Что такое файловая система?', '["Способ организации данных на диске", "Утилита для управления разделами", "Метод защиты данных"]', 0),
(5, 'Какая команда создаёт файловую систему?', '["mkfs", "mount", "umount"]', 0),
(5, 'Какой компонент LVM объединяет физические тома?', '["Logical Volume", "Volume Group", "Physical Volume"]', 1),
(5, 'Как увеличить размер логического тома?', '["lvextend", "pvcreate", "vgcreate"]', 0),
(5, 'Какая команда отображает информацию о физических томах?', '["pvs", "lvs", "vgs"]', 0);
-- Тесты для ZFS
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(6, 'Что такое ZFS?', '["Файловая система и менеджер томов", "Только файловая система", "Только менеджер томов"]', 0),
(6, 'Какая команда используется для создания пула ZFS?', '["zpool create", "zfs create", "zpool status"]', 0),
(6, 'Что делает команда zfs snapshot?', '["Создаёт снимок файловой системы", "Удаляет файловую систему", "Проверяет статус пула"]', 0),
(6, 'Какой тип RAID позволяет сбой двух дисков?', '["RAID-Z1", "RAID-Z2", "RAID-Z3"]', 1),
(6, 'Как включить сжатие данных в ZFS?', '["zfs set compression=on", "zfs set compress=enable", "zpool compress=on"]', 0);

-- Тесты для NFS и FUSE
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(7, 'Для чего используется NFS?', '["Для удалённого доступа к файлам", "Для создания виртуальных машин", "Для мониторинга системы"]', 0),
(7, 'Какой файл редактируется для экспорта каталога в NFS?', '["/etc/exports", "/etc/fstab", "/etc/nfs.conf"]', 0),
(7, 'Для чего предназначен FUSE?', '["Для создания файловых систем в пространстве пользователя", "Для организации удалённого доступа", "Для работы с сетевыми протоколами"]', 0),
(7, 'Как подключить каталог через NFS?', '["mount", "exportfs", "fuse"]', 0),
(7, 'Какой пакет требуется для клиента NFS в Linux?', '["nfs-common", "nfs-server", "fuse"]', 0);

-- Тесты для Резервное копирование
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(8, 'Какое резервное копирование копирует все данные?', '["Полное", "Инкрементное", "Дифференциальное"]', 0),
(8, 'Какая команда используется для создания архива?', '["rsync", "tar", "borg"]', 1),
(8, 'Что означает правило 3-2-1?', '["3 копии, 2 устройства, 1 копия за пределами офиса", "3 устройства, 2 копии, 1 раз в день", "3 копии, 2 раза в день, 1 на сервере"]', 0),
(8, 'Какой инструмент поддерживает инкрементное копирование с шифрованием?', '["rsync", "tar", "borgbackup"]', 2),
(8, 'Как автоматизировать резервное копирование?', '["Использовать cron", "Использовать ssh", "Использовать tar"]', 0);
-- Тесты для MySQL: Backup + Репликация
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(9, 'Какой инструмент позволяет выполнять горячее резервное копирование MySQL?', '["mysqldump", "tar", "rsync"]', 0),
(9, 'Какой параметр конфигурации включает бинарные логи?', '["log-bin", "server-id", "bin-log"]', 0),
(9, 'Как узнать текущую позицию бинарного лога?', '["SHOW MASTER STATUS", "SHOW SLAVE STATUS", "SELECT * FROM logs"]', 0),
(9, 'Какой параметр отвечает за идентификатор сервера в конфигурации?', '["log-bin", "server-id", "replication-id"]', 1),
(9, 'Что показывает параметр Seconds_Behind_Master?', '["Задержку слейва относительно мастера", "Размер бинарного лога", "Количество слейвов"]', 0);
-- Тесты для PostgreSQL: Backup + Репликация
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(10, 'Какой инструмент используется для создания логического дампа?', '["pg_dump", "pg_basebackup", "psql"]', 0),
(10, 'Что такое WAL-файлы?', '["Write-Ahead Logging файлы для восстановления данных", "Логи ошибок PostgreSQL", "Файлы конфигурации"]', 0),
(10, 'Какой параметр конфигурации включает репликацию?', '["wal_level", "archive_mode", "max_connections"]', 0),
(10, 'Какая команда показывает состояние репликации на мастере?', '["SELECT * FROM pg_stat_replication;", "SHOW MASTER STATUS;", "SELECT * FROM pg_stat_wal_receiver;"]', 0),
(10, 'Какой тип репликации позволяет реплицировать отдельные таблицы?', '["Логическая", "Физическая", "RAID"]', 0);
-- Тесты для Управление пакетами и дистрибьюция софта
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(11, 'Какой файл отвечает за репозитории APT?', '["/etc/apt/sources.list", "/etc/yum.conf", "/etc/pacman.conf"]', 0),
(11, 'Какая команда обновляет список пакетов в DNF?', '["sudo dnf update", "sudo apt update", "sudo pacman -Syu"]', 0),
(11, 'Как добавить новый репозиторий в YUM?', '["Создать файл в /etc/yum.repos.d/", "/etc/apt/sources.list", "Использовать pacman -S"]', 0),
(11, 'Как обновить систему в Arch Linux?', '["sudo pacman -Syu", "sudo apt upgrade", "sudo dnf update"]', 0),
(11, 'Как запустить автоматическое обновление через cron?', '["crontab -e", "systemctl enable cron", "nano /etc/cron.daily/update"]', 0);
-- Тесты для Загрузка системы
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(12, 'Какой файл отвечает за конфигурацию GRUB?', '["/boot/grub/grub.cfg", "/etc/systemd/system.conf", "/etc/fstab"]', 0),
(12, 'Какой процесс отвечает за запуск служб после загрузки ядра?', '["init", "GRUB", "UEFI"]', 0),
(12, 'Какая команда отображает текущую версию ядра?', '["uname -r", "cat /proc/cpuinfo", "systemctl status"]', 0),
(12, 'Что нужно настроить для архивирования логов загрузки ядра?', '["/var/log/kern.log", "/etc/fstab", "/boot/grub/grub.cfg"]', 0),
(12, 'Какую команду использовать для диагностики служб в systemd?', '["systemctl status", "initctl list", "grub-mkconfig"]', 0);
-- Тесты для Инициализация системы. Systemd
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(13, 'Какой файл описывает unit-службу?', '["/etc/systemd/system/example.service", "/etc/cron.d/example", "/etc/fstab"]', 0),
(13, 'Какой инструмент используется для просмотра логов служб?', '["journalctl", "systemctl", "syslog"]', 0),
(13, 'Как включить службу для автоматического запуска?', '["sudo systemctl enable service_name", "sudo systemctl start service_name", "sudo service enable"]', 0),
(13, 'Какая команда показывает время загрузки системы?', '["systemd-analyze", "systemctl status", "journalctl -b"]', 0),
(13, 'Как активировать постоянное отображение новых записей логов?', '["sudo journalctl -f", "sudo journalctl -n", "sudo systemctl logs"]', 0);
-- Тесты для Bash
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(14, 'Какая команда показывает текущий каталог?', '["pwd", "ls", "cd"]', 0),
(14, 'Как сделать файл исполняемым?', '["chmod +x file", "make file", "exec file"]', 0),
(14, 'Что делает команда ls?', '["Показывает список файлов и директорий", "Переходит в каталог", "Удаляет файл"]', 0),
(14, 'Как написать простой скрипт?', '["В текстовом редакторе с shebang #!/bin/bash", "Использовать команду script", "Выполнять команды напрямую"]', 0),
(14, 'Как перенаправить вывод команды в файл?', '["ls > output.txt", "ls | output.txt", "ls >> output.txt"]', 0);
-- Тесты для grep, sed, awk и другие
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(15, 'Какая команда находит строку "error" в файле?', '["grep \\"error\\" file.txt", "awk \\"error\\" file.txt", "sed \\"error\\" file.txt"]', 0),
(15, 'Какой инструмент используется для замены текста?', '["sed", "grep", "wc"]', 0),
(15, 'Как извлечь второй столбец из файла?', '["awk \'{print $2}\' file.txt", "grep $2 file.txt", "sed \'print $2\' file.txt"]', 0),
(15, 'Как удалить повторяющиеся строки из файла?', '["uniq file.txt", "sort file.txt", "cut file.txt"]', 0),
(15, 'Как сортировать строки в обратном порядке?', '["sort -r file.txt", "sort file.txt", "uniq -r file.txt"]', 0);
-- Тесты для Управление процессами
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(16, 'Какой инструмент позволяет просматривать текущие процессы?', '["ps", "cron", "lsof"]', 0),
(16, 'Как завершить процесс по PID?', '["kill PID", "ps -9 PID", "htop PID"]', 0),
(16, 'Как изменить приоритет запущенного процесса?', '["renice", "nice", "strace"]', 0),
(16, 'Что делает команда strace?', '["Трассирует системные вызовы", "Завершает процесс", "Показывает приоритет процесса"]', 0),
(16, 'Как запланировать задачу через cron?', '["crontab -e", "systemctl start timer", "ps -e cron"]', 0);
-- Тесты для Работа с памятью
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(17, 'Какая команда показывает информацию о свободной памяти?', '["free", "top", "vmstat"]', 0),
(17, 'Как включить Swap?', '["swapon", "free", "top"]', 0),
(17, 'Какая команда очищает кэш?', '["sudo echo 3 > /proc/sys/vm/drop_caches", "sync", "vmstat"]', 0),
(17, 'Как создать файл подкачки?', '["fallocate -l 1G /swapfile", "swapon -s", "free -m"]', 0),
(17, 'Какой инструмент используется для анализа утечек памяти?', '["valgrind", "perf", "smem"]', 0);
-- Тесты для Механизмы изоляции и аккаунтинга Linux (namespaces и cgroups)
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(18, 'Какой namespace используется для изоляции сетевых интерфейсов?', '["NET", "PID", "UTS"]', 0),
(18, 'Какое действие выполняет команда unshare?', '["Создаёт новый namespace", "Удаляет cgroup", "Устанавливает лимиты ресурсов"]', 0),
(18, 'Какой файл используется для задания лимита CPU в cgroups?', '["cpu.cfs_quota_us", "cpu.stat", "cgroup.procs"]', 0),
(18, 'Как установить ограничение памяти для службы через systemd?', '["systemctl set-property", "cgexec --memory", "lscgroup set-memory"]', 0),
(18, 'Какой инструмент используется для создания нагрузки на ресурсы?', '["stress", "unshare", "cgexec"]', 0);
-- Тесты для SELinux - когда всё запрещено
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(19, 'Какой режим SELinux блокирует запрещённые действия?', '["Enforcing", "Permissive", "Disabled"]', 0),
(19, 'Как временно переключить SELinux в permissive?', '["setenforce 0", "sestatus permissive", "chcon permissive"]', 0),
(19, 'Как показать контексты безопасности файлов?', '["ls -Z", "ps -eZ", "audit2why"]', 0),
(19, 'Какой инструмент анализирует логи SELinux?', '["audit2why", "semodule", "sestatus"]', 0),
(19, 'Как установить пользовательский модуль SELinux?', '["semodule -i", "audit2allow -M", "setenforce 1"]', 0);
-- Тесты для LDAP. Централизованная авторизация и аутентификация
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(20, 'Что такое DN в контексте LDAP?', '["Уникальный идентификатор записи", "Атрибут записи", "Пользовательская группа"]', 0),
(20, 'Какую команду использовать для добавления записей в LDAP?', '["ldapadd", "ldapsearch", "ldapcompare"]', 0),
(20, 'Какой файл используется для добавления записей?', '["LDIF", "JSON", "XML"]', 0),
(20, 'Какая команда позволяет искать записи в LDAP?', '["ldapsearch", "ldapadd", "ldapmodify"]', 0),
(20, 'Как проверить статус пользователей из LDAP в Linux?', '["getent passwd", "getent ldapusers", "ldapstatus"]', 0);
-- Тесты для Пользователи и группы. Авторизация и аутентификация
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(21, 'В каком файле хранятся зашифрованные пароли пользователей?', '["/etc/shadow", "/etc/passwd", "/etc/group"]', 0),
(21, 'Как добавить пользователя в группу?', '["usermod -aG group_name user_name", "groupadd group_name user_name", "useradd -G group_name user_name"]', 0),
(21, 'Какая команда показывает UID пользователя?', '["id", "groups", "whoami"]', 0),
(21, 'Как создать новую группу?', '["groupadd group_name", "useradd -g group_name", "addgroup group_name"]', 0),
(21, 'Какой файл содержит информацию о группах?', '["/etc/group", "/etc/passwd", "/etc/shadow"]', 0);
-- Тесты для Docker: основы работы с контейнеризацией
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(22, 'Какой командой запускается контейнер?', '["docker run", "docker start", "docker create"]', 0),
(22, 'Какой файл используется для создания образа Docker?', '["Dockerfile", "docker-compose.yml", "config.yaml"]', 0),
(22, 'Какая команда показывает все контейнеры?', '["docker ps -a", "docker list", "docker show"]', 0),
(22, 'Как остановить работающий контейнер?', '["docker stop", "docker remove", "docker pause"]', 0),
(22, 'Как загрузить образ в Docker Hub?', '["docker push", "docker pull", "docker upload"]', 0);
-- Тесты для Docker: Volumes and Networks
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(23, 'Какой тип хранения данных в Docker сохраняется при удалении контейнера?', '["Volume", "Bind Mount", "Temporary"]', 0),
(23, 'Как создать Bridge-сеть?', '["docker network create my_bridge", "docker create network my_bridge", "docker bridge create my_bridge"]', 0),
(23, 'Какая команда показывает список сетей?', '["docker network ls", "docker network show", "docker network display"]', 0),
(23, 'Как удалить Volume?', '["docker volume rm my_volume", "docker volume delete my_volume", "docker rm my_volume"]', 0),
(23, 'Какая команда используется для привязки контейнера к сети?', '["docker run --network", "docker connect --network", "docker link --network"]', 0);
-- Тесты для Мониторинг производительности
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(24, 'Какая команда показывает процессы в реальном времени?', '["top", "vmstat", "iotop"]', 0),
(24, 'Какой инструмент используется для мониторинга сетевых подключений?', '["ss", "iostat", "perf"]', 0),
(24, 'Какой инструмент предоставляет полную информацию о системе?', '["nmon", "vmstat", "mpstat"]', 0),
(24, 'Какая команда используется для мониторинга ввода/вывода?', '["iotop", "mpstat", "ss"]', 0),
(24, 'Какая система используется для долгосрочного мониторинга метрик?', '["Prometheus", "htop", "perf"]', 0);
-- Тесты для Prometheus
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(25, 'Какой файл используется для настройки Prometheus?', '["prometheus.yml", "config.json", "prometheus.conf"]', 0),
(25, 'Какой компонент Prometheus используется для сбора метрик?', '["Exporter", "Alertmanager", "Pushgateway"]', 0),
(25, 'Какой язык запросов используется в Prometheus?', '["PromQL", "SQL", "GrafQL"]', 0),
(25, 'Какая команда запускает сервер Prometheus?', '["./prometheus --config.file=prometheus.yml", "./prometheus start", "prometheus-server start"]', 0),
(25, 'Для чего используется Grafana в связке с Prometheus?', '["Для визуализации данных", "Для хранения метрик", "Для управления экспортёрами"]', 0);
-- Тесты для Zabbix
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(26, 'Какой компонент Zabbix отвечает за сбор данных с хостов?', '["Zabbix Agent", "Zabbix Proxy", "Zabbix Frontend"]', 0),
(26, 'Какой SQL-запрос создаёт базу данных Zabbix?', '["CREATE DATABASE zabbix CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;", "CREATE DATABASE zabbix COLLATE utf8_bin;", "CREATE DATABASE zabbix;"]', 0),
(26, 'Какая информация хранится в базе данных Zabbix?', '["Конфигурация и данные мониторинга", "Только конфигурация", "Только данные мониторинга"]', 0),
(26, 'Какой компонент используется для распределения нагрузки в больших сетях?', '["Zabbix Proxy", "Zabbix Server", "Zabbix Agent"]', 0),
(26, 'Какая команда перезапускает Zabbix Agent?', '["sudo systemctl restart zabbix-agent", "sudo systemctl reload zabbix-agent", "sudo systemctl reboot zabbix-agent"]', 0);
-- Тесты для Основы сбора и хранения логов
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(27, 'Какой порт используется rsyslog для отправки логов по TCP?', '["514", "9200", "5601"]', 0),
(27, 'Какой инструмент из ELK Stack используется для обработки логов?', '["Logstash", "Elasticsearch", "Kibana"]', 0),
(27, 'Как включить удалённый приём логов в rsyslog?', '["Добавить модуль imtcp в конфигурацию", "Изменить файл /etc/logrotate.conf", "Включить journalctl --remote"]', 0),
(27, 'Какая команда перезапускает Logstash?', '["sudo systemctl restart logstash", "logstash --reload", "logstash --start"]', 0),
(27, 'Какой инструмент используется для визуализации логов?', '["Kibana", "rsyslog", "Logstash"]', 0);
-- Тесты для ELK
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(28, 'Какой компонент ELK отвечает за хранение данных?', '["Elasticsearch", "Logstash", "Kibana"]', 0),
(28, 'Какой фильтр используется для удаления полей в Logstash?', '["mutate", "grok", "geoip"]', 0),
(28, 'Какая команда удаляет индексы в Elasticsearch?', '["curl -X DELETE", "curl -X REMOVE", "curl -X TRUNCATE"]', 0),
(28, 'Для чего используется Snapshot API в Elasticsearch?', '["Для резервного копирования", "Для удаления данных", "Для индексации данных"]', 0),
(28, 'Какой инструмент используется для фильтрации данных в ELK?', '["Logstash", "Kibana", "Elasticsearch"]', 0);
-- Тесты для Архитектура сетей
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(29, 'Какой уровень модели OSI отвечает за маршрутизацию данных между сетями?', '["Сетевой", "Канальный", "Транспортный"]', 0),
(29, 'Какой тип топологии использует центральный коммутатор?', '["Звезда", "Кольцо", "Шина"]', 0),
(29, 'Какой протокол преобразует доменные имена в IP-адреса?', '["DNS", "DHCP", "HTTP"]', 0),
(29, 'Какой стандарт используется для беспроводных локальных сетей?', '["Wi-Fi", "Ethernet", "Bluetooth"]', 0),
(29, 'Какой инструмент используется для анализа сетевого трафика?', '["Wireshark", "NetFlow", "SNMP"]', 0);
-- Тесты для DHCP, PXE
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(30, 'Какой протокол используется для назначения IP-адресов?', '["DHCP", "TFTP", "PXE"]', 0),
(30, 'Какой файл используется для настройки PXE-загрузки?', '["pxelinux.0", "dhcpd.conf", "tftp.conf"]', 0),
(30, 'Какой протокол используется для передачи загрузочных файлов?', '["TFTP", "HTTP", "FTP"]', 0),
(30, 'Какой параметр указывает на TFTP-сервер в файле dhcpd.conf?', '["next-server", "boot-server", "tftp-server"]', 0),
(30, 'Какой протокол используется для передачи IP-адресов и сетевых параметров?', '["DHCP", "PXE", "SNMP"]', 0);
-- Тесты для Фильтрация трафика - iptables
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(31, 'Какой параметр используется для добавления нового правила в цепочку?', '["-A", "-D", "-L"]', 0),
(31, 'Какое действие сбрасывает пакет без уведомления отправителя?', '["DROP", "REJECT", "ACCEPT"]', 0),
(31, 'Какой параметр позволяет сохранить текущие правила iptables?', '["iptables-save", "iptables-export", "iptables-backup"]', 0),
(31, 'Какой модуль используется для перенаправления трафика?', '["nat", "filter", "mangle"]', 0),
(31, 'Какое правило разрешает доступ к порту 443?', '["iptables -A INPUT -p tcp --dport 443 -j ACCEPT", "iptables -A OUTPUT -p udp --sport 443 -j ACCEPT", "iptables -D INPUT -p tcp --dport 443 -j ACCEPT"]', 0);
-- Тесты для Фильтрация трафика - firewalld
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(32, 'Какой инструмент используется для управления firewalld?', '["firewall-cmd", "iptables", "nft"]', 0),
(32, 'Какой параметр используется для открытия порта?', '["--add-port", "--open-port", "--allow-port"]', 0),
(32, 'Какой параметр делает изменения firewalld постоянными?', '["--permanent", "--persistent", "--save"]', 0),
(32, 'Какой тип зоны в firewalld обеспечивает минимальную безопасность?', '["public", "drop", "home"]', 0),
(32, 'Какое правило блокирует доступ от конкретного IP?', '["rich-rule", "forward-rule", "port-rule"]', 0);
-- Тесты для Фильтрация трафика - nftables
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(33, 'Какой инструмент используется для управления nftables?', '["nft", "iptables", "firewall-cmd"]', 0),
(33, 'Какой командой добавляется новая таблица в nftables?', '["nft add table ip filter", "nft add iptable filter", "nft add chain ip filter"]', 0),
(33, 'Какой командой удаляется правило из nftables?', '["nft delete rule ip filter input handle 5", "nft remove rule ip filter input 5", "nft delete table ip filter handle 5"]', 0),
(33, 'Какой командой можно сохранить текущие правила nftables?', '["nft list ruleset > /etc/nftables.conf", "nft save ruleset", "nft export ruleset"]', 0),
(33, 'Какое правило разрешает доступ к порту 443?', '["nft add rule ip filter input tcp dport 443 accept", "nft add rule ip filter output tcp sport 443 accept", "nft add chain ip filter input tcp port 443 accept"]', 0);
-- Тесты для Статическая и динамическая маршрутизация, OSPF
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(34, 'Какой протокол используется для динамической маршрутизации?', '["OSPF", "ICMP", "FTP"]', 0),
(34, 'Какой командой добавляется статический маршрут?', '["ip route add", "ip route set", "ip route create"]', 0),
(34, 'Какой алгоритм используется в OSPF для определения кратчайшего пути?', '["Дейкстра", "Беллмана-Форда", "Флойд-Уоршелла"]', 0),
(34, 'Какой инструмент используется для настройки OSPF?', '["FRRouting", "tcpdump", "iptables"]', 0),
(34, 'Какой параметр используется для просмотра таблицы маршрутов?', '["ip route show", "ip show routes", "route show ip"]', 0);
-- Тесты для BGP
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(35, 'Какой протокол используется для маршрутизации между автономными системами?', '["BGP", "OSPF", "RIP"]', 0),
(35, 'Какой параметр указывает на следующего маршрутизатора в BGP?', '["NEXT_HOP", "AS_PATH", "MED"]', 0),
(35, 'Какой атрибут маршрута используется для выбора между несколькими точками выхода?', '["MED", "LOCAL_PREF", "COMMUNITY"]', 0),
(35, 'Какой инструмент используется для просмотра состояния BGP в FRRouting?', '["vtysh", "bgpctl", "ip route"]', 0),
(35, 'Какой тип BGP используется внутри одной автономной системы?', '["iBGP", "eBGP", "BGP-LS"]', 0);
-- Тесты для Мосты, туннели и VPN
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(36, 'Какой инструмент используется для создания мостов в Linux?', '["bridge-utils", "iptables", "iproute2"]', 0),
(36, 'Какой тип туннеля использует шифрование?', '["WireGuard", "GRE", "IP-in-IP"]', 0),
(36, 'Какой протокол используется OpenVPN для создания туннелей?', '["UDP/TCP", "IP-in-IP", "GRE"]', 0),
(36, 'Какой порт по умолчанию используется OpenVPN?', '["1194", "443", "80"]', 0),
(36, 'Какой инструмент позволяет настроить GRE-туннель в Linux?', '["iproute2", "bridge-utils", "openvpn"]', 0);
-- Тесты для DNS - настройка и обслуживание
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(37, 'Какой тип записи используется для преобразования доменного имени в IPv4-адрес?', '["A", "AAAA", "MX"]', 0),
(37, 'Какой инструмент используется для проверки зоны DNS?', '["named-checkzone", "dig", "nslookup"]', 0),
(37, 'Какая опция включает рекурсию в Bind9?', '["recursion yes", "allow-query", "recursive-allow"]', 0),
(37, 'Какой файл хранит записи зоны в Bind9?', '["db.example.com", "named.conf.options", "named.conf.local"]', 0),
(37, 'Какая запись используется для указания почтового сервера домена?', '["MX", "CNAME", "NS"]', 0);
-- Тесты для Сетевые пакеты. VLAN'ы. LACP
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(38, 'Какой инструмент позволяет анализировать сетевые пакеты?', '["Wireshark", "tcpdump", "netstat"]', 0),
(38, 'Какой протокол используется для объединения каналов в LACP?', '["802.3ad", "802.1Q", "802.11ac"]', 0),
(38, 'Какой модуль необходим для работы с VLAN в Linux?', '["8021q", "bonding", "vlan_utils"]', 0),
(38, 'Какой файл конфигурации используется для настройки bonding в Linux?', '["/etc/network/interfaces", "/etc/vlan.conf", "/etc/bonding.conf"]', 0),
(38, 'Какой VLAN ID используется в следующей команде? sudo ip link add link eth0 name eth0.10 type vlan id 10', '["10", "eth0", "192.168.10.1"]', 0);
-- Тесты для IPv6
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(39, 'Сколько битов содержится в IPv6-адресе?', '["128", "64", "32"]', 0),
(39, 'Какой тип адреса используется для отправки данных всем участникам группы?', '["Multicast", "Unicast", "Anycast"]', 0),
(39, 'Какой протокол безопасности встроен в IPv6?', '["IPSec", "SSL", "TLS"]', 0),
(39, 'Какая команда добавляет IPv6-адрес к интерфейсу?', '["ip -6 addr add", "ip addr add", "ip link add"]', 0),
(39, 'Какой инструмент используется для трассировки маршрутов IPv6?', '["traceroute6", "traceroute", "tracepath"]', 0);
-- Тесты для Web: протоколы
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(40, 'Какой протокол используется для безопасной передачи данных в Интернете?', '["HTTPS", "HTTP", "FTP"]', 0),
(40, 'Какой метод HTTP используется для удаления данных на сервере?', '["DELETE", "GET", "POST"]', 0),
(40, 'Какой порт используется для HTTPS?', '["443", "80", "21"]', 0),
(40, 'Какой инструмент используется для отправки HTTP-запросов из командной строки?', '["curl", "telnet", "tcpdump"]', 0),
(40, 'Какой метод HTTP используется для отправки данных на сервер?', '["POST", "GET", "DELETE"]', 0);
-- Тесты для Nginx
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(41, 'Какой порт используется Nginx для HTTP по умолчанию?', '["80", "443", "8080"]', 0),
(41, 'Какой файл отвечает за глобальную конфигурацию Nginx?', '["/etc/nginx/nginx.conf", "/etc/nginx/sites-available/default", "/etc/nginx/sites-enabled/example"]', 0),
(41, 'Какой модуль используется для обратного проксирования в Nginx?', '["proxy_pass", "reverse_proxy", "load_balance"]', 0),
(41, 'Какой командой проверяется конфигурация Nginx?', '["nginx -t", "nginx -check", "nginx -conf"]', 0),
(41, 'Какой модуль используется для настройки SSL/TLS в Nginx?', '["ssl_certificate", "tls_config", "secure_cert"]', 0);
-- Тесты для Динамический веб
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(42, 'Какой язык используется для добавления интерактивности на стороне клиента?', '["JavaScript", "Python", "PHP"]', 0),
(42, 'Какой модуль используется для работы с базами данных в Flask?', '["SQLAlchemy", "pandas", "requests"]', 0),
(42, 'Какой протокол используется для связи в реальном времени?', '["WebSocket", "REST", "HTTP"]', 0),
(42, 'Какой инструмент используется для маршрутизации запросов в Flask?', '["@app.route", "@app.path", "@app.route_path"]', 0),
(42, 'Какой метод HTTP используется для отправки данных на сервер?', '["POST", "GET", "DELETE"]', 0);
-- Тесты для MySQL
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(43, 'Какой язык используется для работы с MySQL?', '["SQL", "Python", "Java"]', 0),
(43, 'Какая команда создаёт таблицу в MySQL?', '["CREATE TABLE", "ADD TABLE", "MAKE TABLE"]', 0),
(43, 'Какой инструмент используется для резервного копирования базы данных MySQL?', '["mysqldump", "mysqlbackup", "sqlbackup"]', 0),
(43, 'Какое ключевое слово используется для выбора данных в MySQL?', '["SELECT", "GET", "FETCH"]', 0),
(43, 'Как подключиться к MySQL через терминал?', '["mysql -u root -p", "mysql -connect", "mysql -login"]', 0);
-- Тесты для PostgreSQL
INSERT INTO tests (course_id, question, options, correct_option) VALUES
(44, 'Какой язык используется для работы с PostgreSQL?', '["SQL", "Python", "Java"]', 0),
(44, 'Какая команда создаёт базу данных в PostgreSQL?', '["CREATE DATABASE", "ADD DATABASE", "MAKE DATABASE"]', 0),
(44, 'Какой инструмент используется для резервного копирования PostgreSQL?', '["pg_dump", "postgres_backup", "sqlbackup"]', 0),
(44, 'Какое ключевое слово используется для выбора данных в PostgreSQL?', '["SELECT", "GET", "FETCH"]', 0),
(44, 'Какой модуль Python используется для работы с PostgreSQL?', '["psycopg2", "pymysql", "sqlalchemy_pg"]', 0);
