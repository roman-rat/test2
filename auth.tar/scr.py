import os

# Список категорий и тем
categories = {
    "Виртуализация и автоматизация": ["Vagrant", "Ansible-1", "Ansible-2"],
    "Файловые системы и управление данными": [
        "Дисковая подсистема",
        "Файловые системы и LVM - 1",
        "ZFS",
        "NFS, FUSE",
        "Резервное копирование",
        "MySQL: Backup + Репликация",
        "PostgreSQL: Backup + Репликация",
    ],
    "Управление пакетами и загрузка системы": [
        "Управление пакетами. Дистрибьюция софта",
        "Загрузка системы",
        "Инициализация системы. Systemd",
    ],
    "Программирование и администрирование в Linux": [
        "Bash",
        "grep, sed, awk и другие",
        "Управление процессами",
        "Работа с памятью",
    ],
    "Безопасность и изоляция": [
        "Механизмы изоляции и аккаунтинга Linux (namespaces и cgroups)",
        "SELinux - когда все запрещено",
        "LDAP. Централизованная авторизация и аутентификация",
        "Пользователи и группы. Авторизация и аутентификация",
    ],
    "Контейнеризация и управление": [
        "Docker: основы работы с контейнеризацией",
        "Docker: Volumes and Networks",
    ],
    "Мониторинг и логирование": [
        "Мониторинг производительности",
        "Prometheus",
        "Zabbix",
        "Основы сбора и хранения логов",
        "Сбор и анализ логов: ELK",
    ],
    "Сети и протоколы": [
        "Архитектура сетей",
        "DHCP, PXE",
        "Фильтрация трафика - iptables",
        "Фильтрация трафика - firewalld",
        "Фильтрация трафика - nftables",
        "Статическая и динамическая маршрутизация, OSPF",
        "BGP",
        "Мосты, туннели и VPN",
        "DNS - настройка и обслуживание",
        "Сетевые пакеты. VLAN'ы. LACP",
        "IPv6",
        "Web: протоколы",
    ],
    "Веб-разработка и базы данных": ["Nginx", "Динамический веб", "MySQL", "PostgreSQL"],
}

# Создаем папку templates, если она не существует
os.makedirs("templates", exist_ok=True)

# Генерируем файлы для каждой темы
for category, topics in categories.items():
    for topic in topics:
        filename = topic.lower().replace(" ", "_").replace(":", "_") + ".html"
        filepath = os.path.join("templates", filename)
        with open(filepath, "w") as f:
            f.write("""{% extends "base.html" %}

{% block title %}Курс: """ + topic + """{% endblock %}

{% block content %}
<section class="course-title">
    <div class="container">
        <h2>Курс: """ + topic + """</h2>
        <p>Описание курса: """ + topic + """</p>
    </div>
</section>
{% endblock %}
""")
print("Шаблоны успешно созданы!")
